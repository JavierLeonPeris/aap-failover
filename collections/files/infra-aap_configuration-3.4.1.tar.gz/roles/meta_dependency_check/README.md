# infra.aap_configuration.meta_dependency_check

This role is designed to be run before any roles in this collection to check that the underlying awx.awx or ansible.controller collection is installed. This is a dependency of together roles and does not need to be explicitly called.

## License

[GPL-3.0](https://github.com/redhat-cop/aap_configuration#licensing)

## Author

[Tom Page](https://github.com/Tompage1994)
